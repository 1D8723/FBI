CREATE TABLE nonPoliceChat (
    id int(11)
    description varchar(255)
    Date date
);